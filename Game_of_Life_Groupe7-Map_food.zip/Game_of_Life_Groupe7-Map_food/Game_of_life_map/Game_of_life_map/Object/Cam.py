import pygame

pygame.init()

# Créer une fenêtre de jeu
screen = pygame.display.set_mode((640, 480))

# Charger l'image
image = pygame.image.load("assets/block.png")

# Définir la position initiale de l'image
position = (0, 0)
screen.blit(image, position)

# Définir le facteur de zoom initial
zoom_factor = 1

# Boucle principale du programme
while True:
    # Détecter si le bouton du milieu de la souris est enfoncé
    if pygame.mouse.get_pressed()[1]:
        # Obtenir le mouvement de la souris depuis la dernière frame
        mouse_movement = pygame.mouse.get_rel()

        # Ajuster le facteur de zoom actuel en fonction du mouvement de la souris
        zoom_factor += mouse_movement[1] / 100

        # Redimensionner l'image en fonction du facteur de zoom actuel
        zoomed_image = pygame.transform.scale(image, (int(image.get_width() * zoom_factor), int(image.get_height() * zoom_factor)))

        # Afficher l'image redimensionnée à sa nouvelle position
        position = (position[0] - mouse_movement[0], position[1] - mouse_movement[1])
        screen.blit(zoomed_image, position)

    # Mettre à jour l'affichage
    pygame.display.flip()

    # Attendre que l'utilisateur ferme la fenêtre
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            pygame.quit()
            quit()