# Game_of_Life_Groupe7
Github page where our python project code will be hosted.

In this repository, you'll find the last in date version of our code.

