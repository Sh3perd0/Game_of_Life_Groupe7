import pygame
import random
from constants.grid_size import GRID_SIZE
import os
from constants.cell_size import CELL_SIZE
from Object.common import *
class Bob:
    def __init__(self, grid_x, grid_y):
        self.grid_x = grid_x #the current position
        self.grid_y = grid_y
        self.speed = 1  # Adjust the speed as needed
        self.history = []
        self.target = self.get_target()
        
        # self.start = self.set_initial_position() # Set the 
    
    # @staticmethod
    # def set_initial_position ():
    #     start = pygame.Vector2 (0,0)
    #     start.x = random.randint(0,GRID_SIZE-1)
    #     start.y = random.randint(0,GRID_SIZE-1)
    #     return start
    

    
    def get_target(self):
        target = pygame.Vector2(0, 0)
        return target
    
    def move(self, dx, dy):
        self.grid_x += dx
        self.grid_y += dy
        # Keep track of the movement history
        # self.history.append((self.grid_x, self.grid_y))


    def move_towards_target(self):
        # Calculate the difference between Bob's position and the target position
        dx = self.target.x - self.grid_x
        dy = self.target.y - self.grid_y

        if dx != 0 : move_horizontal = True
        else: move_horizontal = False

        if move_horizontal:
            # Move horizontally
            dx_direction = 1 if dx > 0 else -1
            dy_direction = 0
        else:
            # Move vertically
            dx_direction = 0
            dy_direction = 1 if dy > 0 else -1

        # Adjust Bob's position based on speed
        dx_move = min(abs(dx), self.speed) * dx_direction
        dy_move = min(abs(dy), self.speed) * dy_direction

        # Move Bob
        self.move(dx_move, dy_move)

    
    @staticmethod
    def get_assets_img():

        tile = pygame.image.load (
                os.path.abspath(
                    os.path.join(os.path.dirname(__file__), "..", "assets", "Bob.png")
                )).convert_alpha()

        return tile 
    
    @staticmethod  
    def get_pixel_bob_size():
        return 321/4, 30
         
    @staticmethod
    def get_scaled_bob(
        width_pixel_size=None, height_pixel_size=None
    ):  # pragma: no cover
        if width_pixel_size is None or height_pixel_size is None:
            width_pixel_size, height_pixel_size = Bob.get_pixel_bob_size()
        return pygame.transform.smoothscale(Bob.get_assets_img(),(width_pixel_size, height_pixel_size)).convert_alpha()
    
        
    @staticmethod
    def get_render_pos (grid_x, grid_y):
  
        iso_poly = get_iso_pos (grid_x, grid_y)
        min_x = min(vertex[0] for vertex in iso_poly) 
        min_y = min(vertex[1] for vertex in iso_poly) 
        return [min_x, min_y]

           

