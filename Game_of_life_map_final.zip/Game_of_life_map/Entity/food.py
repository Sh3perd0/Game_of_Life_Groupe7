import pygame
import random
from Object.common import *
from constants.grid_size import GRID_SIZE
import os

class Food:
    def __init__(self):
        self.grid_x = 0
        self.grid_y = 0
        self.energy = 100
    
    def set_position (self):
        self.grid_x = random.randint(0, GRID_SIZE - 1)
        self.grid_y = random.randint(0, GRID_SIZE - 1)
    
    
    @staticmethod
    def get_assets_img():

        tile = pygame.image.load (
                os.path.abspath(
                    os.path.join(os.path.dirname(__file__), "..", "assets", "resourceicons_03.png")
                )).convert_alpha()

        return tile 
    
    @staticmethod  
    def get_pixel_food_size():
        return 321/4, 30
    
    @staticmethod
    def get_scaled_food(
        width_pixel_size=None, height_pixel_size=None
    ):  # pragma: no cover
        if width_pixel_size is None or height_pixel_size is None:
            width_pixel_size, height_pixel_size = Food.get_pixel_food_size()
        return pygame.transform.smoothscale(Food.get_assets_img(),(width_pixel_size, height_pixel_size)).convert_alpha()
    
    @staticmethod
    def get_render_pos (grid_x, grid_y):
  
        iso_poly = get_iso_pos (grid_x, grid_y)
        min_x = min(vertex[0] for vertex in iso_poly) 
        min_y = min(vertex[1] for vertex in iso_poly) 
        return [min_x, min_y]