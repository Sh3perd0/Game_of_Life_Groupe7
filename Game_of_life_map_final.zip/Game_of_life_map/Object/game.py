import pygame 
import sys
from .map import Map
from .camera import Camera
from constants.grid_size import GRID_SIZE
from .bob import Bob
import random
from .common import *
from constants.number_Bob import NUMBER_BOB

class Game:
    
    def __init__ (self, screen, clock):
        self.screen = screen
        self.clock = clock
        self.width, self.height = self.screen.get_size()

        self.camera = Camera(self.width, self.height)
        self.map = Map(GRID_SIZE, GRID_SIZE)
        self.map.render_map()
        self.list_bob = self.create_list_bob()
        

    def run(self):
        self.playing = True
        
        # pygame.display.set_window_position(, )
        while self.playing:
            self.clock.tick (5)
            self.events()
            self.camera.update()
            self.update_move_bob()
            self.draw()

    def events(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    pygame.quit()
                    sys.exit()
    


    def draw (self):
        scroll = self.camera.scroll
        self.screen.fill((0,0,0))
        self.screen.blit(self.map.block_tiles, (scroll.x, scroll.y))
        self.draw_bob()
        self.map.render_map_camera(self.screen, self.camera)
        
        pygame.display.flip()

    def draw_bob(self):
        map_block_tiles = self.map.block_tiles
        scroll = self.camera.scroll
        for bob in self.list_bob :
            render_pos = Bob.get_render_pos(bob.grid_x, bob.grid_y)
            self.screen.blit(bob.get_scaled_bob(), (render_pos[0] + map_block_tiles.get_width()/2 + scroll.x,
                                                     render_pos[1] + map_block_tiles.get_height()/4 + scroll.y))

    def create_list_bob (self):
        bob_list = []
        for _ in range(NUMBER_BOB):
            random_x = random.randint(0, GRID_SIZE - 1)
            random_y = random.randint(0, GRID_SIZE - 1)
            bob = Bob(random_x, random_y)
            bob_list.append(bob) 
        return bob_list  

    def update_move_bob (self):
        for bob in self.list_bob:
            bob.move_towards_target()