import pygame
from random import randint



i=0
nombre_bob=10
dimension_x=1280
dimension_y=700
pygame.init() #init de pygame
screen=pygame.display.set_mode((dimension_x,dimension_y)) #taille screen pygame
clock=pygame.time.Clock() #setup d'une clock
running=True #elle est active

class Bob: #classe blobs qui def leur caracteristiques
    def __init__(self,speed,mass,energy,perception):
        self.size=mass*150
        self.speed=speed
        self.mass=mass
        self.energy=energy
        self.perception=perception
        self.load_bob_sprite = pygame.image.load("bob.png")
        self.load_bob_sprite2 = pygame.image.load("bob2.png")
        self.load_bob_sprite3 = pygame.image.load("bob3.png")
        self.load_bob_sprite4 = pygame.image.load("bob4.png")
        self.load_bob_sprite5 = pygame.image.load("bob5.png")
        self.img_bob = pygame.transform.scale(self.load_bob_sprite,(self.size,self.size))
        self.img_bob2 = pygame.transform.scale(self.load_bob_sprite2,(self.size,self.size))
        self.img_bob3 = pygame.transform.scale(self.load_bob_sprite3,(self.size,self.size))
        self.img_bob4 = pygame.transform.scale(self.load_bob_sprite4,(self.size,self.size))
        self.img_bob5 = pygame.transform.scale(self.load_bob_sprite5,(self.size,self.size))











#def draw_text(text,font,text_col,x,y): #fonction qui affiche du texte
   # img=font.render(text,True,text_col)
   # screen.blit(img,(x,y))

time=150#var arbitraire du randint de deplacement



bob_1=Bob(60,1,1,1)
bob_2=Bob(50,1,1,1)
bob_3=Bob(70,1,1,1)
bob_4=Bob(40,1,1,1)
bob_5=Bob(100,1,1,1)
hauteur=bob_1.img_bob.get_height()
largeur=bob_1.img_bob.get_width()

taille_possible_x=randint(hauteur,1920)
taille_possible_y=randint(largeur,1080)

liste_bob_possible_sprite=[bob_1.img_bob,bob_2.img_bob2,bob_3.img_bob3,bob_4.img_bob4,bob_5.img_bob5]
liste_bob_possible=[bob_1,bob_2,bob_3,bob_4,bob_5]



liste_nombre_bob=[]
for i in range(nombre_bob):
    liste_nombre_bob.append(liste_bob_possible_sprite[randint(0,3)])

positions_x = [randint(400, 1000) for _ in range(nombre_bob)]
positions_y = [randint(200, 600) for _ in range(nombre_bob)]




while running:
    screen.fill((0,0,0)) #permet de colorer le screen en noir ,afin de ne pas laisser de traces lors d'un déplacement par exemple #dessin du rectangle
    key = pygame.key.get_pressed() #réagit à une touche préssée
    for i in range(len(positions_x)):
        random_direction = randint(1, 4)
        
        if random_direction == 1:
            if positions_x[i] > 0 + largeur:
                positions_x[i] -= liste_bob_possible[randint(0, 3)].speed
        elif random_direction == 2:
            if positions_x[i] < dimension_x - largeur:
                positions_x[i] += liste_bob_possible[randint(0, 3)].speed
        elif random_direction == 3:
            if positions_y[i] > 0 + hauteur:
                positions_y[i] -= liste_bob_possible[randint(0, 3)].speed
        elif random_direction == 4:
            if positions_y[i] < dimension_y - hauteur:
                positions_y[i] += liste_bob_possible[randint(0, 3)].speed

    for i in range(len(positions_x)):
        positions_x[i] = max(0, min(dimension_x - largeur, positions_x[i]))
        positions_y[i] = max(0, min(dimension_y - hauteur, positions_y[i]))

    # Blitter les blobs à leurs nouvelles positions
    for i in range(len(liste_nombre_bob)):
        x = positions_x[i]
        y = positions_y[i]
        
        screen.blit(liste_nombre_bob[i], (x, y))


    pygame.time.delay(500)#délai avant actualisation
    pygame.display.flip()#affiche au screen
    
    




    for event in pygame.event.get():
        if key[pygame.K_ESCAPE]:
            running=False#ferme l'interface graphique si echap est appuyé
    pygame.display.update()

    


pygame.quit()







if __name__ == "__main__":
    main()






