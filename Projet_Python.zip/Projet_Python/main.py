
import pygame 
import sys

from Object.game import Game
from Game_of_Life_Groupe7 import Bob

def main():

    running = True
    playing = True

    pygame.init()
    pygame.mixer.init()
    screen = pygame.display.set_mode((0, 0))
    clock = pygame.time.Clock()

    # implement menus
    # implement game
    game = Game(screen, clock)
   
    while running:

        # start menu goes here

        while playing:
            # game loop here
            game.run()

if __name__ == "__main__":
    main()

